const crypto = require('crypto');

exports.handler = async (event) => {
  try {
    const data = JSON.parse(event.body);
    const merchantSecretKey = process.env.WFP_SECRET;

    // Verify signature
    const signString = [
      data.merchantAccount,
      data.orderReference,
      data.amount,
      data.currency,
      data.authCode,
      data.cardPan,
      data.transactionStatus,
      data.reasonCode
    ].join(';');

    const expectedSignature = crypto
      .createHmac('md5', merchantSecretKey)
      .update(signString)
      .digest('hex');

    if (data.merchantSignature !== expectedSignature) {
      console.error('Invalid signature');
      return { statusCode: 400, body: 'Invalid signature' };
    }

    // Log successful payment
    console.log('Payment received:', {
      order: data.orderReference,
      status: data.transactionStatus,
      amount: data.amount
    });

    // Respond to Wayforpay
    const responseSignString = [data.orderReference, 'accept'].join(';');
    const responseSignature = crypto
      .createHmac('md5', merchantSecretKey)
      .update(responseSignString)
      .digest('hex');

    return {
      statusCode: 200,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        orderReference: data.orderReference,
        status: 'accept',
        time: Math.floor(Date.now() / 1000),
        signature: responseSignature
      })
    };

  } catch (error) {
    console.error('Callback error:', error);
    return { statusCode: 500, body: 'Error' };
  }
};
