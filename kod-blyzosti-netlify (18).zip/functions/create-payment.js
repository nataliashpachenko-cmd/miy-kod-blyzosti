const crypto = require('crypto');

exports.handler = async (event) => {
  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, body: 'Method Not Allowed' };
  }

  try {
    const merchantAccount = process.env.WFP_MERCHANT;
    const merchantSecretKey = process.env.WFP_SECRET;
    const merchantDomainName = process.env.WFP_DOMAIN || 'miy-kod-blyzosti.netlify.app';

    const orderReference = 'MKB-' + Date.now();
    const orderDate = Math.floor(Date.now() / 1000);
    const amount = '299';
    const currency = 'UAH';
    const productName = 'Мій код близькості';
    const productCount = '1';
    const productPrice = '299';

    // Wayforpay HMAC_MD5 signature
    const signString = [
      merchantAccount,
      merchantDomainName,
      orderReference,
      orderDate,
      amount,
      currency,
      productName,
      productCount,
      productPrice
    ].join(';');

    const merchantSignature = crypto
      .createHmac('md5', merchantSecretKey)
      .update(signString)
      .digest('hex');

    const paymentData = {
      merchantAccount,
      merchantDomainName,
      merchantSignature,
      orderReference,
      orderDate,
      amount,
      currency,
      productName: [productName],
      productCount: [productCount],
      productPrice: [productPrice],
      returnUrl: `https://${merchantDomainName}/`,
      failedReturnUrl: `https://${merchantDomainName}/`,
      cancelReturnUrl: `https://${merchantDomainName}/`,
      serviceUrl: `https://${merchantDomainName}/.netlify/functions/payment-callback`,
      language: 'UA',
      paymentSystems: 'card;googlePay;applePay'
    };

    return {
      statusCode: 200,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*'
      },
      body: JSON.stringify(paymentData)
    };

  } catch (error) {
    console.error('Payment error:', error);
    return {
      statusCode: 500,
      body: JSON.stringify({ error: 'Помилка створення платежу' })
    };
  }
};
