exports.handler = async (event) => {
  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, body: 'Method Not Allowed' };
  }

  try {
    const { email, name, gender, schemas, score } = JSON.parse(event.body);

    if (!email) {
      return { statusCode: 400, body: 'Email required' };
    }

    // Step 1: Get SendPulse access token
    const tokenRes = await fetch('https://api.sendpulse.com/oauth/access_token', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        grant_type: 'client_credentials',
        client_id: process.env.SENDPULSE_ID,
        client_secret: process.env.SENDPULSE_SECRET
      })
    });
    const tokenData = await tokenRes.json();
    const token = tokenData.access_token;

    if (!token) {
      console.error('SendPulse token error:', tokenData);
      return { statusCode: 200, body: 'OK' }; // Fail silently — don't break test
    }

    // Step 2: Add contact to mailing list
    const addRes = await fetch(`https://api.sendpulse.com/addressbooks/${process.env.SENDPULSE_LIST_ID}/emails`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify({
        emails: [{
          email,
          variables: {
            name: name || '',
            gender: gender === 'f' ? 'Жінка' : 'Чоловік',
            top_schemas: schemas || '',
            score: score || 0,
            product: 'miy-kod-blyzosti',
            date: new Date().toISOString().split('T')[0]
          }
        }]
      })
    });

    console.log('Contact saved:', email, 'Status:', addRes.status);

    return {
      statusCode: 200,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ success: true })
    };

  } catch (error) {
    console.error('Save contact error:', error);
    return { statusCode: 200, body: 'OK' }; // Fail silently
  }
};
